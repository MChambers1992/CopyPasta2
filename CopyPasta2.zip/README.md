# CopyPasta
CopyPasta is a small utility that enables multi-line/unlimited-length pasting of text or commands into WoW. This is a fork of Paste by the author oscarucb who is missing in action.
[CurseForge Project Page](https://wow.curseforge.com/projects/copypasta)
